# DSN2099
You must have django installed in you computer to run the project
